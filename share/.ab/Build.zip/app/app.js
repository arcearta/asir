var application = require("application");
application.start({ moduleName: "components/login/login" });
